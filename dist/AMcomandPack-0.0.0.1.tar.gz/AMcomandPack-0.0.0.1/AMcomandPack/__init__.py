"the command we write in AM just cleaner"

from AMcomandPack import geo