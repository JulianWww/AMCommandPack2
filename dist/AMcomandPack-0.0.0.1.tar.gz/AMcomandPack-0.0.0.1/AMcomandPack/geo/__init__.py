"rendering"

from AMcomandPack.geo.tk import Tk, Canvas